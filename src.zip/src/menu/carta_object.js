import React from "react";
import './carta_object.css'
import ArctTyr from '../../src/img/ArctTyr.jpg';
import { NavLink } from "react-router-dom";

function CartObj(){
    return(
            <div className="CartObj">
                <NavLink className="ArctTyr" to="/object" ><img src={ArctTyr} alt=""/></NavLink>
                <div className="TekstImg"><h2>Центр арктического туризма</h2><h4>Центр арктического туризма — это этнографический комплекс в Нарьян-Маре. Он работает круглый год и предлагает возможность переночевать, увидеть ненецкий чум, пообщаться с северным оленем и узнать больше о жизни коренных народов Севера. <br></br>На территории центра можно арендовать беседку, баню и ненецкий чум для комфортного отдыха.</h4></div>
            </div>
            
    );
}
export default CartObj;