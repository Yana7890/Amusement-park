import React from "react";
import'../../src/menu/menu.css';
import Poisc from "../../src/menu/poisc.js";
import CartObj from "../../src/menu/carta_object.js";

function Menu(){
    return(
        <div> 
            <Poisc />
            <div className="Menu"><CartObj /></div>
        </div>
    );
}
export default Menu;