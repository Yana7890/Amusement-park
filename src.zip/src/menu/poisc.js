import React from "react";
import Search from '../../src/img/search.png';

function Poisc(){
    return(
        <div> 
            <div className="PoiscRamka">
                <div className="PoiscStroka"> <img className='search' src={Search} alt=""/></div>
            </div>
        </div>
    );
}
export default Poisc;