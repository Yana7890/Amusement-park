import './App.css';
import Head from '../src/head/head.js';
import Menu from '../src/menu/menu.js';
import News from '../src/news/news.js';
import Profile from '../src/profile/profile.js';
import Partners from '../src/partners/partners.js';
import Search from '../src/search/search.js';
import Object from '../src/object/object.js';
import Login from '../src/profile/login.js';
import Registration from '../src/profile/registration.js';
import News1 from '../src/news/news1.js';
import Password from './profile/password.js';
import Back from '../src/profile/login.js';
import Login1 from '../src/profile/login.js';
import RegPar from '../src/partners/regpar.js';
import RegAtr from '../src/partners/regatr.js';
import { Routes, Route } from "react-router-dom";

function App() {
  return (
      <div className='App'>
        <Routes>
          <Route path='/menu' Component={Menu} />
          <Route path='/news' Component={News} />
          <Route path='/profile' Component={Profile} />
          <Route path='/partners' Component={Partners} />
          <Route path='/search' Component={Search} />
          <Route path='/object' Component={Object} />
          <Route path='/login' Component={Login} />
          <Route path='/registration' Component={Registration} />
          <Route path='/news1' Component={News1} />
          <Route path='/password' Component={Password} />
          <Route path='/profile' Component={Back} />
          <Route path='/profile1' Component={Login1} />
          <Route path='/regpar' Component={RegPar} />
          <Route path='/regatr' Component={RegAtr} />
        </Routes>  
      <Head />
      </div>
  );
}

export default App;