import React from "react";
import'./head.css';
import { NavLink } from "react-router-dom";

function Head(){
    return(
    <div className="Head">
        <NavLink className="HeadButtons" to="/menu" >Главное меню</NavLink>
        <NavLink className="HeadButtons" to="/news" >Новости</NavLink>
        <NavLink className="HeadButtons" to="/profile" >Профиль</NavLink>
        <NavLink className="HeadButtons" to="/partners" >Партнеры</NavLink>
        <NavLink className="HeadButtons" to="/search" >Поиск</NavLink>
    </div>
    );
}

export default Head;