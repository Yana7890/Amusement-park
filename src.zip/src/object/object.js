import React from "react";
import'./object.css';
import ArctTyr1 from '../../src/img/ArctTyr.jpg';
import Atr1 from '../../src/img/Atr1.jpg';
import Ticet from '../../src/img/ticket5.png';
import { NavLink } from "react-router-dom";

function Object(){
    return(
        <div className="CAT">
            <img className="ArctTyr1" src={ArctTyr1} alt=""/>
            <div className="Object">
                <div className="ObjOpis"><h4 className="Opis">Центр арктического туризма </h4>
                Центр предлагает сафари на снегоходах, экскурсии в оленеводческие бригады, арктическую охоту и рыбалку, однодневные и многодневные туры к уникальным природным объектам.
                <h4 className="Opis">Адрес</h4>находится в городе Нарьян-Мар, по адресу: 7-й километр Лая-Вожской дороги
                <h4 className="Opis">Режим работы</h4> ежедневно с 09:00 до 18:00, обед с 13:00 до 14:00.
                <h4 className="Opis">Контакты</h4>телефон: +7 (81853) 2-13-36; 13 
                электронная почта: info@visitnao.ru. 1
                </div>
            </div>
            <h1 className="blue">аттракционы</h1>
            <div className="Atrac">
                <div>
                    <NavLink className="" to="/atr" ><img  className="Atr1" src={Atr1} alt=""/></NavLink>
                    <p>НА КРАЮ СТРАНЫ БЕСКРАЙНЕЙ</p>
                    <img  className="Ticet" src={Ticet} alt=""/>
                    <NavLink className="buy_ticket" to="/atr">Купить билет</NavLink>
                </div>
                <div>
                    <NavLink className="" to="/atr" ><img  className="Atr1" src={Atr1} alt=""/></NavLink>
                    <p>НА КРАЮ СТРАНЫ БЕСКРАЙНЕЙ</p>
                    <img  className="Ticet" src={Ticet} alt=""/>
                    <NavLink className="buy_ticket" to="/atr">Купить билет</NavLink>
                </div>
            </div>
        </div>
);
}

export default Object;