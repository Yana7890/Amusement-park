import React from "react";
import'./object.css';

function Object(){
    return(
    <div className="Object"></div>
);
}

export default Object;