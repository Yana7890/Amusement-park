import React from "react";
import'../../src/search/search.css';
import Poisc from "../../src/search/poisc.js";
import Cart from '../../src/img/Cart.jpg';
import Marcer from '../../src/img/marcer.png';

function Search(){
    return(
    <div className="Search">
        <Poisc />
        <div className="Carts">
            <img className='cart' src={Cart} alt="cart"/>
            <img className='Marcer' src={Marcer} alt="Marcer"/>
        </div>
    </div>
);
}

export default Search;