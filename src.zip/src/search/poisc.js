import React from "react";
import Search from '../../src/img/search.png';

function Poisc(){

    return(
        <div> 
            <div className="PoiscRamka">
                <input className="PoiscStroka" placeholder="Поиск"  type="text"></input> <img className='search' src={Search} alt=""/>
                <div className="container">



            </div>
        </div>
        </div>
    );
}
export default Poisc;

