import React from "react";
import './regpar.css';
import { NavLink } from "react-router-dom";
import { useState } from 'react';
import Calendar from 'react-calendar';

function RegPar(){

    return(
        <div className="RegPar">
            
        </div>
    );
}

export default RegPar;