import React from "react";
import './regpar.css';
import { NavLink } from "react-router-dom";
import { useState } from 'react';
import Calendar from 'react-calendar';
import Icon from '../../src/img/icon1.png';

function RegPar(){     
    const [date, setDate] = useState(new Date());
    return(
        <div className="RegBody">
            <div className="RegPar">
                <h1>регистрация</h1>
                <input className="Surname" placeholder="Фамилия" type="text"></input>
                <input className="Name" placeholder="Имя"  type="text"></input>
                <input className="Otchestvo" placeholder="Отчество" type="text"></input>
                <input className="Telephon" placeholder="Телефон"  type="text"></input>
                <input className="E-Meil" placeholder="e-mail" type="text"></input>
                <h1>дата рождения</h1>
                <div className='Center'>
                    <div className='calendar-container'>
                        <Calendar onChange={setDate} value={date} />
                    </div>
                </div>
                <input className="Address" placeholder="Адрес объекта" type="text"></input>
                <input className="City" placeholder="Город объекта"  type="text"></input>
                <input className="NameObject" placeholder="Название объекта" type="text"></input>
                <input className="DescObj" placeholder="Описание объекта"  type="text"></input>
                <h1>Фото объекта</h1>
                <img className="Icon" src={Icon} alt=""/>
                <input className="NameAtr" placeholder="Название аттракциона" type="text"></input>
                <input className="DescAtr" placeholder="Описание аттракциона"  type="text"></input>
                <h1>Фото аттракциона</h1>
                <img className="Icon" src={Icon} alt=""/>
                <NavLink className="regatr" to="/regatr">Добавить поле для атракциона</NavLink>
                <NavLink className="Back2" to="/partners">Назад</NavLink>
                <NavLink className="Reg1" to="/profile3">зарегистрироваться</NavLink>
            </div>
        </div>
    );
}


export default RegPar;