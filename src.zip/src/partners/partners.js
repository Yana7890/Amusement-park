import React from "react";
import'../../src/partners/partners.css';
import Cart from '../../src/img/Cart.jpg';
import Marcer from '../../src/img/marcer.png';
import Avatar from '../../src/img/profile.png';
import { NavLink } from "react-router-dom";

function Partners(){
    return(
    <div className="Partners">
        <div className="Carts">
            <img className='cart' src={Cart} alt="cart"/>
            <img className='Marcer' src={Marcer} alt="Marcer"/>
        </div>
        <div className="PartnersCards">
            <div className="PartnerCard">
                <img className="Avatar" src={Avatar} alt=""/>
                <div className="text">
                    <h2>Фамилия</h2>
                    <h2>Имя</h2> 
                    <h2>Отчество</h2>
                    <h2>Телефон</h2>
                    <h2>Почта</h2>
                    <h2>Парк</h2>
                    <h2>Город</h2>
                </div>
            </div>
            <NavLink className="PartnerButton" to="/profile3">Стать партнером</NavLink>
        </div>
    </div>
);
}

export default Partners;