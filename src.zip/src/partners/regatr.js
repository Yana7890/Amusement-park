import React from "react";
import './regatr.css';
import { NavLink } from "react-router-dom";
import Icon from '../../src/img/icon1.png';

function RegAtr(){     
    return(
        <div className="RegAtr">
            
            <input className="NameAtr" placeholder="Название аттракциона" type="text"></input>
            <input className="DescAtr" placeholder="Описание аттракциона"  type="text"></input>
            <h1>Фото аттракциона</h1>
            <img className="Icon" src={Icon} alt=""/>
            <NavLink className="regatr" to="/regatr">Добавить поле для атракциона</NavLink>
            <NavLink className="Reg" to="/profile3">зарегистрироваться</NavLink>
        </div>
    );
}


export default RegAtr;