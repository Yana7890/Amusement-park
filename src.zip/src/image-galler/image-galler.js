import React from 'react';
import './image-galler.css';
import Now from '../../src/img/Now.jpg';
import Now2 from '../../src/img/Now2.jpg';
import Now3 from '../../src/img/Now3.webp';
import Now4 from '../../src/img/Now4.jpeg';
import { Carousel } from 'react-responsive-carousel';

function ImageGaller(){
      return (
          <Carousel autoPlay interval="6000" transitionTime="1000" infiniteLoop>
              <div>
                  <img src={Now} />
              </div>
              <div>
                  <img src={Now2} />
              </div>
              <div>
                  <img src={Now3} />
              </div>
              <div>
                  <img src={Now4} />
              </div>
              
          </Carousel>

      );

}


export default ImageGaller;