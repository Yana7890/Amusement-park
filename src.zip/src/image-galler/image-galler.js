import React from 'react';
import './image-galler.css';
import I from '../../src/img/i.webp';
import { Carousel } from 'react-responsive-carousel';

function ImageGaller(){
      return (
          <Carousel autoPlay interval="6000" transitionTime="1000" infiniteLoop>
              <div>
                  <img src={I} />
              </div>
              <div>
                  <img src={I} />
              </div>
              <div>
                  <img src={I} />
              </div>
              <div>
                  <img src={I} />
              </div>
              <div>
                  <img src={I} />
              </div>
              <div>
                  <img src={I} />
              </div>
          </Carousel>
      );

}


export default ImageGaller;