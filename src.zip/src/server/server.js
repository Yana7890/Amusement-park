const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Подключение к базе данных
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'root',
  database: 'amusement_park'
});

// Проверка подключения
connection.connect((err) => {
  if (err) {
    console.error('Ошибка подключения: ' + err.stack);
    return;
  }
  console.log('Подключено как ID ' + connection.threadId);
});

// Регистрация пользователя
app.post('/register', async (req, res) => {
  const { login, password, surname, name, otchestvo, telephone, dateOfBirth } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const query = 'INSERT INTO user (login, password, right_of_access, discount) VALUES (?, ?, ?, ?)';
  connection.query(query, [login, hashedPassword, 1, 0], (error) => {
    if (error) {
      return res.status(500).send(error);
    }
    res.status(201).send('Пользователь зарегистрирован');
  });
});

// Вход пользователя
app.post('/login', (req, res) => {
  const { login, password } = req.body;

  const query = 'SELECT * FROM user WHERE login = ?';
  connection.query(query, [login], async (error, results) => {
    if (error || results.length === 0) {
      return res.status(401).send('Неверный логин или пароль');
    }

    const user = results[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).send('Неверный логин или пароль');
    }

    res.status(200).send('Успешный вход');
  });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
