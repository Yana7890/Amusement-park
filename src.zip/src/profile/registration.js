import React from "react";
import './registration.css';
import { NavLink } from "react-router-dom";
import { useState } from 'react';
import Calendar from 'react-calendar';

function Registration(){
    const [date, setDate] = useState(new Date());
    return(
        <div className="Registration">
            <h1>регистрация</h1>
            <input className="Meil" placeholder="Фамилия" type="text"></input>
            <input className="Name" placeholder="Имя"  type="text"></input>
            <input className="Meil" placeholder="Отчество" type="text"></input>
            <input className="Telephon" placeholder="Телефон"  type="text"></input>
            <h1>дата рождения</h1>
            <div className='Center'>
                <div className='calendar-container'>
                    <Calendar onChange={setDate} value={date} />
                </div>
            </div>
            <h1>введите логин и пароль</h1>
            <input className="Meil" placeholder="Логин" type="text"></input>
            <input className="Pass" placeholder="Пароль"  type="text"></input>
            <NavLink className="Back1" to="/profile">Назад</NavLink>
            <NavLink className="Reg" to="/profile2">зарегистрироваться</NavLink>
        </div>
    );
}

export default Registration;