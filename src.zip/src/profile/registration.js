import React from "react";
import './registration.css';
import { NavLink } from "react-router-dom";
import { useState } from 'react';
import Calendar from 'react-calendar';

function Registration() {
    const [surname, setSurname] = useState('');
    const [name, setName] = useState('');
    const [otchestvo, setOtchestvo] = useState('');
    const [telephone, setTelephone] = useState('');
    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');
    const [date, setDate] = useState(new Date());
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      const response = await fetch('http://localhost:3000/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          surname,
          name,
          otchestvo,
          telephone,
          login,
          password,
          dateOfBirth: date.toISOString().split('T')[0], // Преобразуем дату в формат YYYY-MM-DD
        }),
      });
  
      const data = await response.text();
      alert(data);
    };
    return(
        <div className="Registration">
        <h1>Регистрация</h1>
        <form onSubmit={handleSubmit}>
          <input
            className="Surname"
            placeholder="Фамилия"
            type="text"
            value={surname}
            onChange={(e) => setSurname(e.target.value)}
          />
          <input
            className="Name"
            placeholder="Имя"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            className="Otchestvo"
            placeholder="Отчество"
            type="text"
            value={otchestvo}
            onChange={(e) => setOtchestvo(e.target.value)}
          />
          <input
            className="Telephone"
            placeholder="Телефон"
            type="text"
            value={telephone}
            onChange={(e) => setTelephone(e.target.value)}
          />
          <h1>Дата рождения</h1>
          <div className='Center'>
            <div className='calendar-container'>
              <Calendar onChange={setDate} value={date} />
            </div>
          </div>
          <h1>Введите логин и пароль</h1>
        <input
          className="Meil"
          placeholder="Логин"
          type="text"
          value={login}
          onChange={(e) => setLogin(e.target.value)}
        />
        <input
          className="Pass"
          placeholder="Пароль"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
            <NavLink className="Back1" to="/profile">Назад</NavLink>
            <NavLink className="Reg" to="/profile2">зарегистрироваться</NavLink>
            </form>
        </div>
        
    );
}

export default Registration;

