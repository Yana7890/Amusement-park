import React from "react";
import './registration.css';
import { NavLink } from "react-router-dom";

function Registration(){
    return(
        <div className="Registration">
            <h1>регистрация</h1>
            <input className="Meil" placeholder="Фамилия" type="text"></input>
            <input className="Password" placeholder="Имя"  type="password"></input>
            <input className="Meil" placeholder="Отчество" type="text"></input>
            <input className="Password" placeholder="Телефон"  type="password"></input>
            <h1>дата рождения</h1>
            <h1>введите логин и пароль</h1>
            <input className="Meil" placeholder="Логин" type="text"></input>
            <input className="Password" placeholder="Пароль"  type="password"></input>
            <NavLink className="Back1" to="/profile">Назад</NavLink>
            <NavLink className="Reg" to="/profile2">зарегистрироваться</NavLink>
        </div>
    );
}

export default Registration;