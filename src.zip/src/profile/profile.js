import React from "react";
import '../../src/profile/profile.css';
import { NavLink } from "react-router-dom";
import Avatar from '../../src/img/profile.png';


function Profile(){
    return(
        <div className="Profile">
            <img className="Avatar" src={Avatar} alt=""/>
            <NavLink className="LoginButtons" to="/registration" >Зарегестрироватья</NavLink>
            <NavLink className="LoginButtons" to="/login">Войти</NavLink>
        </div>
);
}

export default Profile;