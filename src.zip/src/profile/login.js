import React, { useState } from 'react';
import './login.css';
import { NavLink } from "react-router-dom";

function Login() {
    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ login, password }),
      });
      const data = await response.text();
      alert(data);
    };
  
    return (
      <div className="Login">
        <h1>Войти</h1>
        <form className="Logins" onSubmit={handleSubmit}>
          <input placeholder="Логин" type="text" value={login} onChange={(e) => setLogin(e.target.value)} />
          <input placeholder="Пароль" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <NavLink className="NoPass" to="/password">Забыли пароль</NavLink>
            <NavLink className="Back" to="/profile">Назад</NavLink>
            <NavLink className="Login1" to="/profile2">Войти</NavLink>
        </form>
      </div>
    );
  }
export default Login;








