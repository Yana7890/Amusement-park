import React from "react";
import './login.css';
import { NavLink } from "react-router-dom";

function Login(){
    return(
        <div className="Login">
            <h1>войти</h1>
            <input className="Meil" placeholder="Логин" type="text"></input>
            <input className="Pass" placeholder="Пароль"  type="password"></input>
            <NavLink className="NoPass" to="/password">Забыли пароль</NavLink>
            <NavLink className="Back" to="/profile">Назад</NavLink>
            <NavLink className="Login1" to="/profile2">Войти</NavLink>
        </div>
    );
}
export default Login;