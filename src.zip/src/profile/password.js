import React from "react";
import './password.css';
import { NavLink } from "react-router-dom";

function Password(){
    return(
        <div className="Password">
            <h1>Восстановление пароля</h1>
            <input className="Meil" placeholder="Логин" type="text"></input>
            <input className="Telephon" placeholder="Телефон"  type="text"></input>
            <p className="TextPass">для полтверждения введите логин и номер телефона</p>
            <NavLink className="Login1" to="/profile2">Войти</NavLink>
        </div>
    );
}
export default Password;