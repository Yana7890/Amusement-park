import React from "react";
import './password.css';
import { NavLink } from "react-router-dom";

function Password(){
    return(
        <div className="Passwords">
            <h1>Восстановление пароля</h1>
            <input className="Meil">Логин</input>
            <input className="Telephon">Телефон</input>
            <h6>для полтверждения введите логин и номер телефона</h6>
            <NavLink className="Login1" to="/profile1">Войти</NavLink>
        </div>
    );
}
export default Password;