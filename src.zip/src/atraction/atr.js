import React from "react";
import './atr.css'
import ArctTyr1 from '../../src/img/ArctTyr.jpg';
import Ticet from '../../src/img/ticket5.png';
import { NavLink } from "react-router-dom";
import ImageGaller2 from "../../src/image-galler/image-galler2.js";
import Avatar from '../../src/img/profile.png';

function Atr(){
    return(
        <div className="Atr">

            <ImageGaller2/>
            <div className="DesAtr">
                <img  className="Ticet1" src={Ticet} alt=""/>
                <NavLink className="ticket" to="/atr">Купить билет</NavLink>
                <img  className="Ticet1" src={Ticet} alt=""/>
                <NavLink className="ticket" to="/atr">Заброни-
                ровать </NavLink>
                <h3><strong> Маршрут:</strong> "На краю страны бескрайней" <tr/>

                    <strong> Сезон:</strong>  Зима <tr/>

                    <strong>Продолжительность:</strong> 5 дней/4 ночи <tr/>

                    <strong>Состав группы:</strong> 3-6 человек <tr/>

                    <strong>Стоимость:</strong> 75 000 руб./чел. <tr/>

                    <strong>Организатор:</strong> "Красный город", туроператор <tr/>

                    <strong>Адрес:</strong> Гостиница "Печора", ул. Ленина, д.31, г. Нарьян-Мар, Ненецкий АО, 166000
                </h3>
                    <details className="contacts"><summary><strong> Контакты:</strong><tr/></summary>
                        - Телефон: 8 (818-53) 4-10-70 <tr/>
                        - Мобильный: +7 911 590-15-90 <tr/>
                        - Email: info@vseonao.ru <tr/>
                        - Сайт: vseonao.ru<tr/>
                    </details>
                      
                    <details className="discrAtr">
                    <summary> <strong>Описание:</strong> </summary>
                    <strong>Возрастная категория:</strong> Тур для подготовленных туристов от 14 лет. <tr/>

                    <strong>Сложность:</strong> Средняя. <tr/>

                    <strong>Состав группы:</strong> 3-6 человек <a className="PS">(водители, пассажиры на снегоходах или в санях).</a> <tr/>

                    <strong>Продолжительность:</strong>5 дней/4 ночи,  общий пробег на снегоходе около 400 км.<tr/>

                    <strong>Программа:</strong> <tr/>
                        - День 1: Прилет в Нарьян-Мар, трансфер и размещение в гостинице. Обед, знакомство группы, посещение музея, инструктаж по туру.<tr/>
                        - День 2: Трансфер к оленеводам, знакомство с культурой, катание на оленьей упряжке, посещение мастерской, размещение на турбазе, подледная рыбалка и мастер-класс по выживанию.<tr/>
                        - День 3: Поездка к Северному Ледовитому Океану, экскурсия по полярной гидрометеостанции, общение с метеорологами.<tr/>
                        - День 4: Завтрак, обратный путь в Нарьян-Мар, экспресс-экскурсия, трансфер в аэропорт.<tr/>

                        <strong>Стоимость:</strong> 75 000 руб./человек. <tr/>
                        <a className="PS">(Включает пропуск в пограничную зону, экскурсии, проживание, питание, услуги гида и снегоходную экипировку.) </a><tr/>

                        <strong>Дополнительно:</strong> Баня с веником за 3 500 руб. <tr/>

                        <strong>Полезные советы:</strong> Удобная тёплая одежда, фотоаппарат, личные гигиенические принадлежности, два комплекта термобелья.<tr/>
                    </details>
                   
            </div>
             <h1 className="blue">Отзывы</h1>
             <div className="reviews">
                <img className="MinAvatar" src={Avatar} alt=""/>
                <input className="feedback"></input>
             </div>
        </div>
);
}

export default Atr;