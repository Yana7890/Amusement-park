import React, { useState } from "react";
import './atr.css';
import ArctTyr1 from '../../src/img/ArctTyr.jpg'; // Замените на нужный путь к изображению
import Ticet from '../../src/img/ticket5.png'; // Замените на нужный путь к изображению
import { NavLink } from "react-router-dom";
import ImageGaller2 from "../../src/image-galler/image-galler2.js";
import Avatar from '../../src/img/profile.png'; // Замените на нужный путь к изображению

function Atr() {
    const [reviews, setReviews] = useState([]);
    const [feedback, setFeedback] = useState('');

    const handleFeedbackChange = (e) => {
        setFeedback(e.target.value);
    };

    const handleFeedbackSubmit = (e) => {
        e.preventDefault();
        if (feedback.trim()) {
            setReviews([...reviews, feedback]);
            setFeedback(''); // Очистить поле ввода после отправки
        }
    };

    return (
        <div className="Atr">
            <ImageGaller2 />
            <div className="DesAtr">
                <img className="Ticet1" src={Ticet} alt="Билет" />
                <NavLink className="ticket" to="/atr">Купить билет</NavLink>
                <img className="Ticet1" src={Ticet} alt="Билет" />
                <NavLink className="ticket" to="/atr">Заброни-
                ровать</NavLink>
                <h3>
                    <strong>Маршрут:</strong> "На краю страны бескрайней" <br />
                    <strong>Сезон:</strong> Зима <br />
                    <strong>Продолжительность:</strong> 5 дней/4 ночи <br />
                    <strong>Состав группы:</strong> 3-6 человек <br />
                    <strong>Стоимость:</strong> 75 000 руб./чел. <br />
                    <strong>Организатор:</strong> "Красный город", туроператор <br />
                    <strong>Адрес:</strong> Гостиница "Печора", ул. Ленина, д.31, г. Нарьян-Мар, Ненецкий АО, 166000
                </h3>
                <details className="contacts">
                    <summary><strong>Контакты:</strong></summary>
                    - Телефон: 8 (818-53) 4-10-70 <br />
                    - Мобильный: +7 911 590-15-90 <br />
                    - Email: info@vseonao.ru <br />
                    - Сайт: vseonao.ru
                </details>

                <details className="discrAtr">
                    <summary><strong>Описание:</strong></summary>
                    <strong>Возрастная категория:</strong> Тур для подготовленных туристов от 14 лет. <br />
                    <strong>Сложность:</strong> Средняя. <br />
                    <strong>Состав группы:</strong> 3-6 человек <a className="PS">(водители, пассажиры на снегоходах или в санях).</a> <br />
                    <strong>Продолжительность:</strong> 5 дней/4 ночи, общий пробег на снегоходе около 400 км.<br />
                    <strong>Программа:</strong> <br />
                    - День 1: Прилет в Нарьян-Мар, трансфер и размещение в гостинице. Обед, знакомство группы, посещение музея, инструктаж по туру.<br />
                    - День 2: Трансфер к оленеводам, знакомство с культурой, катание на оленьей упряжке, посещение мастерской, размещение на турбазе, подледная рыбалка и мастер-класс по выживанию.<br />
                    - День 3: Поездка к Северному Ледовитому Океану, экскурсия по полярной гидрометеостанции, общение с метеорологами.<br />
                    - День 4: Завтрак, обратный путь в Нарьян-Мар, экспресс-экскурсия, трансфер в аэропорт.<br />
                    <strong>Стоимость:</strong> 75 000 руб./человек. <br />
                    <a className="PS">(Включает пропуск в пограничную зону, экскурсии, проживание, питание,
                        транспорт и услуги гида.)</a>
                </details>
                </div>
                <h1 className="blue">Отзывы</h1>
                <div className="feedback-section">
                
                <img src={Avatar} alt="Аватар" className="avatar" /><form onSubmit={handleFeedbackSubmit}>
                        <textarea
                            value={feedback}
                            onChange={handleFeedbackChange}
                            placeholder="Оставьте ваш отзыв"
                            required
                        />
                        <button type="submit">Отправить отзыв</button>
                    </form>
                    <ul>
                        {reviews.map((review, index) => (
                            <li key={index}>
                                <img src={Avatar} alt="Аватар" className="avatar" />
                                <p>{review}</p>
                            </li>
                        ))}
                    </ul>
               
            </div>
        </div>
    );
}

export default Atr;
