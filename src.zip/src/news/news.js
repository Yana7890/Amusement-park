import React from "react";
import'../../src/news/news.css';
import Now from '../../src/img/Now.jpg';
import { NavLink } from "react-router-dom";

function News(){
    return(
    <div className="News">
        <NavLink className="TextNow" to="/news1">В Астрахани начался демонтаж самого крупного в городе парка аттракционов</NavLink>
        <img className="Now" src={Now} alt=""/>
        
    </div>
);
}

export default News;