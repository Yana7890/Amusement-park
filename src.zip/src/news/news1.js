import React from "react";
import'../../src/news/news1.css';



function News1(){
    return(
    <div className="News1">
    </div>
);
}
export default News1;