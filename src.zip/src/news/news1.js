import React from "react";
import'../../src/news/news1.css';
import ImageGaller from '../../src/image-galler/image-galler.js';

function News1(){
    return(
    <div className="News1">
        <ImageGaller/>
    </div>
);
}
export default News1;